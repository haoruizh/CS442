#include "color.h"

const Color blackColor   (0, 0, 0);
const Color blueColor    (0, 0, 1);
const Color cyanColor    (0, 1, 1);
const Color greenColor   (0, 1, 0);
const Color magentaColor (1, 0, 1);
const Color redColor     (1, 0, 0);
const Color whiteColor   (1, 1, 1);
const Color yellowColor  (1, 1, 0);

const Rgb blackRgb       (0, 0, 0);
