pa02_wire_track: Making OpenGL Draw a Rollercoaster Track in 3D
===============================================================

In this programming assignment, you will start to build the *coaster*
application in earnest, with a 3D curve indicating the path the rails
will follow and vertical lines indicating curves.

